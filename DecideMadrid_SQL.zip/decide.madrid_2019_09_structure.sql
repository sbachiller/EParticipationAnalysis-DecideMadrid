/*
SQLyog Community v12.09 (64 bit)
MySQL - 5.7.10-log : Database - decide.madrid_2019_09
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`decide.madrid_2019_09` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_bin */;

/*Table structure for table `cat_categories` */

DROP TABLE IF EXISTS `cat_categories`;

CREATE TABLE `cat_categories` (
  `id` int(11) NOT NULL,
  `name` varchar(48) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Table structure for table `cat_category_tags_seeds` */

DROP TABLE IF EXISTS `cat_category_tags_seeds`;

CREATE TABLE `cat_category_tags_seeds` (
  `tag` varchar(48) COLLATE utf8_bin NOT NULL,
  `category` varchar(48) COLLATE utf8_bin NOT NULL,
  `weight` float DEFAULT NULL,
  PRIMARY KEY (`tag`,`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Table structure for table `cat_topic_tags` */

DROP TABLE IF EXISTS `cat_topic_tags`;

CREATE TABLE `cat_topic_tags` (
  `tag` varchar(48) COLLATE utf8_bin NOT NULL,
  `topic` varchar(48) COLLATE utf8_bin NOT NULL,
  `category` varchar(48) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`tag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Table structure for table `cat_topics` */

DROP TABLE IF EXISTS `cat_topics`;

CREATE TABLE `cat_topics` (
  `id` int(48) NOT NULL,
  `topic` varchar(48) COLLATE utf8_bin NOT NULL,
  `category` varchar(48) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Table structure for table `geo_district_tags` */

DROP TABLE IF EXISTS `geo_district_tags`;

CREATE TABLE `geo_district_tags` (
  `id` int(11) NOT NULL,
  `tag` varchar(48) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`,`tag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Table structure for table `geo_districts` */

DROP TABLE IF EXISTS `geo_districts`;

CREATE TABLE `geo_districts` (
  `id` int(11) NOT NULL,
  `name` varchar(48) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Table structure for table `geo_locations` */

DROP TABLE IF EXISTS `geo_locations`;

CREATE TABLE `geo_locations` (
  `location` varchar(128) COLLATE utf8_bin NOT NULL,
  `street` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `type` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `neighborhood` int(11) NOT NULL,
  `district` int(11) DEFAULT NULL,
  PRIMARY KEY (`location`,`neighborhood`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Table structure for table `geo_neighborhood_tags` */

DROP TABLE IF EXISTS `geo_neighborhood_tags`;

CREATE TABLE `geo_neighborhood_tags` (
  `id` int(11) NOT NULL,
  `tag` varchar(48) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`,`tag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Table structure for table `geo_neighborhoods` */

DROP TABLE IF EXISTS `geo_neighborhoods`;

CREATE TABLE `geo_neighborhoods` (
  `id` int(11) NOT NULL,
  `name` varchar(48) COLLATE utf8_bin DEFAULT NULL,
  `districtId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Table structure for table `geo_pois` */

DROP TABLE IF EXISTS `geo_pois`;

CREATE TABLE `geo_pois` (
  `poi` varchar(128) COLLATE utf8_bin NOT NULL,
  `district` int(11) NOT NULL,
  `neighborhood` int(11) NOT NULL,
  PRIMARY KEY (`poi`,`district`,`neighborhood`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Table structure for table `geo_streets` */

DROP TABLE IF EXISTS `geo_streets`;

CREATE TABLE `geo_streets` (
  `street` varchar(64) COLLATE utf8_bin NOT NULL,
  `district` int(11) NOT NULL,
  `neighborhood` int(11) NOT NULL,
  PRIMARY KEY (`street`,`district`,`neighborhood`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Table structure for table `proposal_categories` */

DROP TABLE IF EXISTS `proposal_categories`;

CREATE TABLE `proposal_categories` (
  `id` int(11) NOT NULL,
  `category` varchar(48) COLLATE utf8_bin NOT NULL,
  `weight` double NOT NULL,
  `n_weight` double NOT NULL,
  `source` varchar(16) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Table structure for table `proposal_comments` */

DROP TABLE IF EXISTS `proposal_comments`;

CREATE TABLE `proposal_comments` (
  `id` int(11) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `proposalId` int(11) DEFAULT NULL,
  `page` int(11) DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  `userType` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `date` date DEFAULT NULL,
  `time` time DEFAULT NULL,
  `text` text COLLATE utf8_bin,
  `numVotes` int(11) DEFAULT NULL,
  `numPositiveVotes` int(11) DEFAULT NULL,
  `numNegativeVotes` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Table structure for table `proposal_locations` */

DROP TABLE IF EXISTS `proposal_locations`;

CREATE TABLE `proposal_locations` (
  `id` int(11) NOT NULL,
  `district` varchar(64) COLLATE utf8_bin NOT NULL,
  `neighborhood` varchar(64) COLLATE utf8_bin NOT NULL,
  `location` varchar(128) COLLATE utf8_bin NOT NULL,
  `tag` varchar(128) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`,`district`,`neighborhood`,`location`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Table structure for table `proposal_tags` */

DROP TABLE IF EXISTS `proposal_tags`;

CREATE TABLE `proposal_tags` (
  `id` int(11) NOT NULL,
  `tag` varchar(48) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`,`tag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Table structure for table `proposal_topics` */

DROP TABLE IF EXISTS `proposal_topics`;

CREATE TABLE `proposal_topics` (
  `id` int(11) NOT NULL,
  `topic` varchar(48) COLLATE utf8_bin NOT NULL,
  `weight` double NOT NULL,
  `n_weight` double NOT NULL,
  `source` varchar(16) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Table structure for table `proposals` */

DROP TABLE IF EXISTS `proposals`;

CREATE TABLE `proposals` (
  `id` int(11) NOT NULL,
  `url` varchar(256) COLLATE utf8_bin DEFAULT NULL,
  `code` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `title` varchar(256) COLLATE utf8_bin DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `summary` text COLLATE utf8_bin,
  `text` text COLLATE utf8_bin,
  `numComments` int(11) DEFAULT NULL,
  `status` varchar(16) COLLATE utf8_bin DEFAULT NULL,
  `numSupports` int(11) DEFAULT NULL,
  `isAssociation` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(128) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
